<?php

 return [
     'printers' => 'Drucker',
     'add_printer' => 'Drucker hinzufügen',
     'name' => 'Druckername',
     'connection_type' => 'Verbindungstyp',
     'capability_profile' => 'Fähigkeitsprofil',
     'ip_address' => 'IP Adresse',
     'port' => 'Hafen',
     'path' => 'Pfad',
     'added_success' => 'Drucker wurde erfolgreich hinzugefügt',
     'manage_your_printers' => 'Verwalten Sie Ihre Drucker',
     'all_your_printer' => 'Alle konfigurierten Drucker',
     'deleted_success' => 'Drucker wurde erfolgreich gelöscht',
     'edit_printer_setting' => 'Druckerkonfiguration bearbeiten',
     'receipt_printers' => 'Bondrucker',
     'character_per_line' => 'Zeichen pro Zeile',
     'printer_name' => 'Druckername',
     'updated_success' => 'Drucker wurde erfolgreich aktualisiert',
     'edit_printer' => 'Drucker bearbeiten',
 ];
