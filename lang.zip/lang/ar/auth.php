<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'خطأ باسم المستخدم او كلمة السر',
    'throttle' => 'محاولات خاطئة كثيرة. يرجى المحاولة مره اخرى بعد :seconds ثانية.',
];
