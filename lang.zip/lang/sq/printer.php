<?php

 return [
     'printers' => 'Printers',
     'add_printer' => 'Shto printer',
     'name' => 'Emri i printerit',
     'connection_type' => 'Lloji i lidhjes',
     'capability_profile' => 'Profili i aftësive',
     'ip_address' => 'Adresa IP',
     'port' => 'Port',
     'path' => 'Rrugë',
     'added_success' => 'Printeri u shtua me sukses',
     'manage_your_printers' => 'Menaxhoni printuesit tuaj',
     'all_your_printer' => 'Të gjithë printerët e konfiguruar',
     'deleted_success' => 'Printer u fshi me sukses',
     'edit_printer_setting' => 'Ndrysho konfigurimin e printerit',
     'receipt_printers' => 'Printera të Marrjes',
     'character_per_line' => 'Figurë për rresht',
     'printer_name' => 'Emri i printerit',
     'updated_success' => 'Printer u rifreskua me sukses',
     'edit_printer' => 'Edit Printer',
 ];
