<?php

 return [
     'home' => 'Home',
     'welcome_message' => 'Mirësevini :name,',
     'total_sell' => 'Shitjet totale',
     'total_purchase' => 'Blerje gjithsej',
     'invoice_due' => 'Fatura për shkak',
     'purchase_due' => 'Blerje për shkak',
     'today' => 'Sot',
     'this_week' => 'Këtë javë',
     'this_month' => 'Këtë muaj',
     'this_fy' => 'Ky vit financiar',
     'sells_last_30_days' => 'Shitjet e fundit 30 ditë',
     'sells_current_fy' => 'Shitjet Viti i tanishëm financiar',
     'total_sells' => 'Shitjet totale (:currency)',
     'product_stock_alert' => 'Produkt Alert Stock',
     'payment_dues' => 'Pagesa Pagesa',
     'due_amount' => 'Shuma e duhur',
     'stock_expiry_alert' => 'Alarmi i skadimit të aksioneve',
     'todays_profit' => 'Fitimi i sotëm',
 ];
