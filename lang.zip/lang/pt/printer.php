<?php

 return [
     'printers' => 'Impressoras',
     'add_printer' => 'Adicionar impressora',
     'name' => 'Nome da impressora',
     'connection_type' => 'Tipo de conexão',
     'capability_profile' => 'Perfil de capacidade',
     'ip_address' => 'endereço IP',
     'port' => 'Port',
     'path' => 'Caminho',
     'added_success' => 'Impressora adicionada com sucesso',
     'manage_your_printers' => 'Gerenciar suas impressoras',
     'all_your_printer' => 'Todas as impressoras configuradas',
     'deleted_success' => 'Impressora apagada com sucesso',
     'edit_printer_setting' => 'Editar configurações da impressora',
     'receipt_printers' => 'Impressoras de recibos',
     'character_per_line' => 'Caracteres por linha',
     'printer_name' => 'Nome da impressora',
     'updated_success' => 'Impressora atualizada com sucesso',
     'edit_printer' => 'Editar impressora',
 ];
